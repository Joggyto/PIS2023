/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Jonathan
 */
public class DetalleSalida extends Movimiento{
    
    private int idDetalleSalidaProducto;
    private int idSalidaProducto;
    private int idProducto;

    public int getIdDetalleSalidaProducto() {
        return idDetalleSalidaProducto;
    }

    public void setIdDetalleSalidaProducto(int idDetalleSalidaProducto) {
        this.idDetalleSalidaProducto = idDetalleSalidaProducto;
    }

    public int getIdSalidaProducto() {
        return idSalidaProducto;
    }

    public void setIdSalidaProducto(int idSalidaProducto) {
        this.idSalidaProducto = idSalidaProducto;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }
    
    
    
}
